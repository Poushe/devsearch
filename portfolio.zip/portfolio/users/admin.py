from django.contrib import admin
from .models import profile, skills

# Register your models here.
admin.site.register(profile)
admin.site.register(skills)

